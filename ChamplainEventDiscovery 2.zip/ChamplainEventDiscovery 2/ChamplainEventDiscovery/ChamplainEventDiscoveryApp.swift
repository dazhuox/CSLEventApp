//
//  ChamplainEventDiscoveryApp.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-02.
//

import SwiftUI

@main
struct ChamplainEventDiscoveryApp: App {
    
    @StateObject
    var viewModel: ChamplainEventDiscoveryViewModel = ChamplainEventDiscoveryViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
