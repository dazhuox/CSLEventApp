//
//  Post.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct Post: Identifiable {
    var id: String {title}
    let title: String
    let accountImage: String
    let account: String
    let image: String
    let description: String
}
