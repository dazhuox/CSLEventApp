//
//  TopBarView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-05.
//

import SwiftUI

struct TopBarView: View {
    var body: some View {
        
        VStack {
            HStack {
                Text("CSL Event Link")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.trailing, 110)
                
                Spacer()
                        
                    
            }
            .padding(.top, 20)
            
        }
    }
}

struct TopBarView_Previews: PreviewProvider {
    static var previews: some View {
        TopBarView()
    }
}
