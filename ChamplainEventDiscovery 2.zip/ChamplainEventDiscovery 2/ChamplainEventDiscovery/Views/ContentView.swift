//
//  ContentView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-02.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var viewModel: ChamplainEventDiscoveryViewModel
    
    var body: some View {
        TabView {
            NavigationStack{
                
                VStack{
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 20) {
                            
                            ForEach(viewModel.post) { post in
                                PostView(image: post.image, title: post.title, accountImage: post.accountImage, account: post.image, description: post.description)
                            }
                        }
                    }
                    .navigationTitle("Home")
                    .toolbar {
                        
                        ToolbarItemGroup(placement: .navigationBarLeading) {
                            
                            TopBarView()
                            
                            HStack {
                                
                                NavigationLink(destination: SearchBarView(), label: {Image(systemName: "magnifyingglass")})
                                
                                // add logic so it only shows this link if user is not logged in
                                NavigationLink(destination: ProfileView(), label: {Image(systemName: "person.crop.circle")})
                            }
                            .padding(.trailing, 20)
                            .padding(.top, 20)
                            
                        }
                    }
                    Spacer()
                }
            }
            .tabItem() {
                Text("Home")
            }
            
            Text("My Events page")
                .tabItem() {
                    Text("Your Events")
                }
            MemoryView(title: "Beavertails Foodtruck with Friends", eventName: "Beavertail Foodtruck", eventDate: Date(), eventImage: "BeavertailsP", myImages: ["BeavertailsM"], myThoughts: "Yummy")
                .tabItem() {
                    Text("Memories")
                }
            Text("Profile page")
                .tabItem() {
                    Text("Profile")
                }
            Text("Profile page")
                .tabItem() {
                    Text("Profile")
                }
        }
    }
}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
