//
//  SearchBarView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-18.
//

import SwiftUI

struct SearchBarView: View {
    var body: some View {
        
        Text("This is the Search bar view.")
            .font(.title)
            .frame(width: 500, height: 20)
        
        Text("A search bar will be implmented soon.")
    }
}

struct SearchBarView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBarView()
    }
}
