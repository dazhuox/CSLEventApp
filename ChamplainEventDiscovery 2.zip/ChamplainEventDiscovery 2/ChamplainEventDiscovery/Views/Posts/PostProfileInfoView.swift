//
//  PostProfileInfoView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct PostProfileInfoView: View {
    var body: some View {
        
        HStack {
            Image("CSA")
                .resizable()
                .frame(width: 70, height: 70)
            Text("Title")
                .font(.title2)
                .fontWeight(.medium)
            Spacer()
        }

    }
}

struct PostProfileInfoView_Previews: PreviewProvider {
    static var previews: some View {
        PostProfileInfoView()
    }
}
