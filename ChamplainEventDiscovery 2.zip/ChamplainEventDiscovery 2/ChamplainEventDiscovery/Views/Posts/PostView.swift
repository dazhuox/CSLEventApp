//
//  PostView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct PostView: View {
    
    var image: String
    var title: String
    var accountImage: String
    var account: String
    var description: String
    
    @EnvironmentObject var viewModel: ChamplainEventDiscoveryViewModel
    
    var body: some View {
        VStack {
            Spacer()
            PostProfileInfoView()
            
            Image(image)
                .resizable()
                .frame(width: 400, height: 400)
            
            Text(description)
                .frame(width: 400, height: 100)
                .font(.caption)
                .fontWeight(.medium)
            Spacer()
        }
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(image: "Beavertails", title: "Beavertails Foodtruck", accountImage: "CSA", account: "mycsa.ca", description: "Beavertails is coming on campus! Come get a FREE Beavertail outside the cafeteria this free block from 12h30 to 14h30! Two flavors available: Cinnamon Sugar and Chocolate Hazelnut. Student ID needed! See you there :)") .previewLayout(.sizeThatFits)
    }
}
