//
//  ProfileView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-18.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("This is the profile view")
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
