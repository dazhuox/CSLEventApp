//
//  ChamplainEventDiscoveryApp.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-02.
//

import SwiftUI
import Firebase

@main
struct ChamplainEventDiscoveryApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
