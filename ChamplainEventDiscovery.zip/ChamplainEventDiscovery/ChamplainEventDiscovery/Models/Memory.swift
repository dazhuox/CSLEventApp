//
//  Memory.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct Memory: Identifiable {
    var id: String {title}
    let title: String
    let eventName: String
    let eventDate: String
    let eventImage: String
    let myImages: [String]
    let myThoughts: String
}
