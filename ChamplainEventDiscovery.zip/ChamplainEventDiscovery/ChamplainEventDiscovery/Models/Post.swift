//
//  Post.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import FirebaseFirestoreSwift

struct Post: Identifiable, Codable {
    @DocumentID var id: String?
    var title: String = ""
    var account: String = ""
    var description: String = ""
    
    init() {
        
    }
    
    init(title: String, account: String, description: String)  {
        self.title = title
        self.account = account
        self.description = description
    }
}
