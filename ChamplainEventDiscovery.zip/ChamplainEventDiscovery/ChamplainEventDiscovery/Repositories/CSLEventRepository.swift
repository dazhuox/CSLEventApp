//
//  CSLEventRepository.swift
//  ChamplainEventDiscovery
//
//  Created by Da Zhuo Xie on 2023-11-19.
//

import FirebaseFirestore
import FirebaseFirestoreSwift

class CSLEventRepository: ObservableObject {
    
    static var shared = CSLEventRepository()
    
    @Published var list: [Post] = []
    
    private let path = "posts"
    private let store = Firestore.firestore()
    
    init() {
        get()
    }
    func get() {
        store.collection(path).addSnapshotListener { snapshot, error in
            
            if let error = error {
                print(error)
                return
            }
            
            //We for sure have a snapshot if we made it thru error
            
            self.list = snapshot?.documents.compactMap {
                try? $0.data(as: Post.self)
            } ?? []
        }
    }
    
    func add(_ post: Post) {
        do {
            _ = try store.collection(path).addDocument(from: post)
        }
        catch {
            fatalError("Adding a post failed")
        }
    }
    
    func update(_ post:Post) {
        if let documentId = post.id {
            store.collection(path).document(documentId).setData(["title": post.title, "account": post.account, "description": post.description], merge: true)
        }
    }
    
    func delete(_ post:Post) {
        if let documentId = post.id {
            store.collection(path).document(documentId).delete {
                error in
                if let error = error {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
}
