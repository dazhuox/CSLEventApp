//
//  ChamplainEventDiscoveryViewModel.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import Combine

class ChamplainEventDiscoveryViewModel: ObservableObject {
    
    @Published var CSLRepo = CSLEventRepository.shared
    @Published var postList = [Post]()
    @Published var toBeUpdatedPost = Post()
    
    private var cancellables: Set<AnyCancellable> = []
    
//    var post: [Post] = [
//        Post(title: "Beavertails Foodtruck", account: "mycsa.ca", description: "Beavertails is coming on campus! Come get a FREE Beavertail outside the cafeteria this free block from 12h30 to 14h30! Two flavors available: Cinnamon Sugar and Chocolate Hazelnut. Student ID needed! See you there :)"),
//        
//        Post(title: "Free Breakfast", account: "mycsa.ca", description: "Join us this Friday from 7:45 to 11:00 for free breakfast!"),
//        
//        Post(title: "Spa Giveaway", account: "mycsa.ca", description: "The winner will be announced tomorrow and you have 24 hours to enter!")
//    ]
    
    init() {
        self.CSLRepo.$list
            .assign(to: \.postList, on: self)
            .store(in: &cancellables)
        
        for post in self.postList {
            print("Post: \(post.title); \(post.account); \(post.description)")
        }
    }
    
    func addPost(post: Post) {
        CSLRepo.add(post)
    }
    
    func updatePost() {
        CSLRepo.update(toBeUpdatedPost)
    }
    
    func deletePost(post: Post) {
        CSLRepo.delete(post)
    }
}
