//
//  ContentView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-02.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var viewModel = ChamplainEventDiscoveryViewModel()
    
    @State var title = ""
    @State var account = ""
    @State var description = ""
    
    var body: some View {
        TabView {
            NavigationStack{
                
                VStack{
                    
//                    ScrollView(.vertical, showsIndicators: false) {
//                        VStack(spacing: 20) {
//                            
////                            ForEach(viewModel.post) { post in
////                                PostView(title: post.title, account: post.account, description: post.description, viewModel: viewModel)
////                            }
//                            PostView()
//                        }
//                    }
                    PostView()
                    .navigationTitle("Home")
                    .toolbar {
                        
                        ToolbarItemGroup(placement: .navigationBarLeading) {
                            
                            TopBarView()
                            
                            HStack {
                                
                                NavigationLink(destination: SearchBarView(), label: {Image(systemName: "magnifyingglass")})
                            }
                            .padding(.trailing, 20)
                            .padding(.top, 20)
                            
                        }
                    }
                    Spacer()
                }
            }
            .tabItem() {
                Label("Home", systemImage: "house")
            }
            
            Text("My Events page")
                .tabItem() {
                    Label("Your Events", systemImage: "bookmark")
                }
            MemoryView(title: "Beavertails Foodtruck with Friends", eventName: "Beavertail Foodtruck", eventDate: Date(), eventImage: "BeavertailsP", myImages: ["BeavertailsM"], myThoughts: "Yummy")
                .tabItem() {
                    Label("Memories", systemImage: "clock.arrow.circlepath")
                }
        }
    }
}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
