//
//  MemoryView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct MemoryView: View {
    
    var title: String
    var eventName: String
    var eventDate: Date
    var myImages: [String]
    var myThoughts: String
    
    var body: some View {
        VStack {
            
            Image("My images")
                .resizable()
                .frame(width: 200, height: 200)
                .cornerRadius(20)
            Spacer()
        }
    }
}

struct MemoryView_Previews: PreviewProvider {
    static var previews: some View {
        MemoryView(title: "Beavertails Foodtruck with Friends", eventName: "Beavertail Foodtruck", eventDate: Date(), myImages: ["BeavertailsM"], myThoughts: "Yummy")
    }
}
