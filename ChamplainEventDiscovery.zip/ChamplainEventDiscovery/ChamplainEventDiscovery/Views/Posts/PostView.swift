//
//  PostView.swift
//  ChamplainEventDiscovery
//
//  Created by macuser on 2023-10-16.
//

import SwiftUI

struct PostView: View {
    
    @ObservedObject var viewModel = ChamplainEventDiscoveryViewModel()
    
    @State var title = ""
    @State var account = ""
    @State var description = ""
    
    var body: some View {
        VStack {
            List(viewModel.postList) { item in
                HStack {
                    VStack {
                        Text(item.title)
                        Text(item.account)
                        Text(item.description)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        title = item.title
                        account = item.account
                        description = item.description
                        
                        viewModel.toBeUpdatedPost = item
                    }, label: {
                        Image(systemName: "pencil")
                    })
                    .buttonStyle(BorderlessButtonStyle())
                    
                    
                    Button(action: {
                        viewModel.deletePost(post: item)
                    }, label: {
                        Image(systemName: "trash")
                    })
                }
            }
            Divider()
            VStack(spacing: 5) {
                TextField("Enter a title", text: $title)
                TextField("Enter account", text: $account)
                TextField("Enter a description", text: $description)

                Button(action: {
                    let post = Post(title: title, account: account, description: description)

                    viewModel.addPost(post: post)
                    title = ""
                    account = ""
                    description = ""
                }, label: {
                    Text("Add a post")
                })
                .buttonStyle(BorderedButtonStyle())
                
                Button(action: {
                    viewModel.toBeUpdatedPost.title = title
                    viewModel.toBeUpdatedPost.account = account
                    viewModel.toBeUpdatedPost.description = description
                    viewModel.updatePost()
                    title = ""
                    account = ""
                    description = ""
                }, label: {
                    Text("Update a post")
                })
                .buttonStyle(BorderedButtonStyle())
                
            }
        }
        
    }
        
    
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView(title: "Beavertails Foodtruck", account: "mycsa.ca", description: "Beavertails is coming on campus! Come get a FREE Beavertail outside the cafeteria this free block from 12h30 to 14h30! Two flavors available: Cinnamon Sugar and Chocolate Hazelnut. Student ID needed! See you there :)").previewLayout(.sizeThatFits)
    }
}
